// src/pages/NotFoundPage.jsx
import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <div>
      <h2>404 - Page Not Found</h2>
      <Link to="/">Return to Dashboard</Link>
    </div>
  );
}